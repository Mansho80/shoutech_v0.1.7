using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ShouTech.App.Configuration;

namespace ShouTech.App.Services
{
    public interface IDataService
    {
        Task<int> GetTotalCustomersAsync();
        Task<int> GetTotalProductsAsync();
        Task<int> GetTotalPendingApprovalsAsync();
        Task<List<RecentDocument>> GetRecentDocumentsAsync(int count);
    }

    public interface ICompanyRegistryService
    {
        Task<List<CompanyInfo>> GetCompaniesAsync();
        Task<bool> HasCompaniesAsync();
    }

    public interface IPermissionService
    {
        bool HasPermission(string permissionKey);
    }

    // ❌ تم إزالة ILocalizationService من هنا
    // لأنه موجود في LocalizationService.cs

    public interface IThemeService
    {
        event EventHandler<bool>? ThemeChanged;

        bool GetCurrentTheme();
        void Initialize(bool isDark);
        void SetTheme(bool isDark);
        void ToggleTheme();
    }

    public interface IBackupService
    {
        void PerformBackup();
    }

    public interface INavigationService
    {
        object NavigateTo(string pageKey);
        Task<object> NavigateToAsync(string pageKey);
        object NavigateToModule(string actionTitle, string moduleKey, string? tabName = null, string? tabHeader = null);
        void ClearCache();
    }

    public interface ILoggingService
    {
        void LogInfo(string category, string message);
        void LogWarning(string category, string message);
        void LogError(string category, string message, Exception? ex = null);
    }

    public class UserModel
    {
        public string UserId { get; set; } = "USER-001";
        public string FullName { get; set; } = "المدير العام";
        public string Email { get; set; } = "admin@shoutech.com";
        public string CompanyName { get; set; } = "شو تيك للبرمجيات";
        public bool IsAuthenticated { get; set; } = true;
        public List<string> Roles { get; set; } = new();
    }

    public class RecentDocument
    {
        public string DocumentNumber { get; set; } = "";
        public string DocumentType { get; set; } = "";
        public DateTime Date { get; set; } = DateTime.Now;
        public string CustomerName { get; set; } = "";
        public decimal TotalAmount { get; set; }
        public string Status { get; set; } = "";
    }
}