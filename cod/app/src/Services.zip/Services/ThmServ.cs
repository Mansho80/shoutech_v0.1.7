using System;
using System.Linq;
using System.Windows;
using ShouTech.App.Configuration;

namespace ShouTech.App.Services
{
    /// <summary>
    /// Enterprise theme manager — swaps merged resource dictionaries at runtime
    /// and persists preference via <see cref="UsrPref"/>.
    /// </summary>
    public sealed class ThmServ : IThmServ
    {
        private const string DkThemeUri = "pack://application:,,,/Themes/DkTheme.xaml";
        private const string LtThemeUri = "pack://application:,,,/Themes/LtTheme.xaml";

        private bool _isDark = true;

        public event EventHandler<bool>? ThemeChanged;

        public bool GetCurrentTheme() => _isDark;

        public void Initialize(bool isDark)
        {
            ApplyThemeInternal(isDark, persist: false);
        }

        public void SetTheme(bool isDark)
        {
            ApplyThemeInternal(isDark, persist: true);
        }

        public void ToggleTheme() => SetTheme(!_isDark);

        private void ApplyThemeInternal(bool isDark, bool persist)
        {
            if (_isDark == isDark && persist)
            {
                var existing = FindThemeDictionary();
                if (existing != null)
                    return;
            }

            _isDark = isDark;
            SwapThemeDictionary(isDark);

            if (persist)
                SavePreference(isDark);

            ThemeChanged?.Invoke(this, isDark);
        }

        private static void SwapThemeDictionary(bool isDark)
        {
            var app = System.Windows.Application.Current;
            if (app == null)
                return;

            var merged = app.Resources.MergedDictionaries;
            var current = FindThemeDictionary();
            if (current != null)
                merged.Remove(current);

            var uri = new Uri(isDark ? DkThemeUri : LtThemeUri, UriKind.Absolute);
            merged.Insert(0, new ResourceDictionary { Source = uri });
        }

        private static ResourceDictionary? FindThemeDictionary()
        {
            var app = System.Windows.Application.Current;
            if (app == null)
                return null;

            return app.Resources.MergedDictionaries
                .FirstOrDefault(d => d.Contains("ThemeName"));
        }

        private static void SavePreference(bool isDark)
        {
            try
            {
                var pref = UsrPref.Load();
                pref.Theme = isDark ? "Dark" : "Light";
                pref.Save();
            }
            catch
            {
                // Non-fatal: theme still applied in memory
            }
        }
    }
}
