// shoutech_erp_v0.1.6/cod/app/src/Services/IBkpServ.cs
using System.Threading;
using System.Threading.Tasks;

namespace ShouTech.App.Services
{
    public interface IBkpServ
    {
        Task<string> CreateBackupAsync(string companyCode, CancellationToken ct = default);
        Task RestoreBackupAsync(string backupFilePath, CancellationToken ct = default);
        Task<bool> ValidateBackupAsync(string backupFilePath, CancellationToken ct = default);
    }
}