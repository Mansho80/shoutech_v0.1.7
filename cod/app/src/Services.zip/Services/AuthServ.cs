using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using ShouTech.App.Common;
using ShouTech.App.Configuration;

namespace ShouTech.App.Services
{
    public sealed class AuthServ : IAuthSvc
    {
        private sealed record CredentialProfile(
            string Id,
            string FullName,
            string Email,
            string Role,
            string RoleCode,
            UsrAccLvl AccessLevel,
            bool IsSuperAdmin);

        private static readonly Dictionary<string, CredentialProfile> Profiles = new(System.StringComparer.OrdinalIgnoreCase)
        {
            ["admin"] = new("USR-001", "مدير النظام", "admin@shoutech.com", "Administrator", "ROLE_SUPERADMIN", UsrAccLvl.Administrator, true),
            ["user"] = new("USR-002", "مستخدم تشغيل", "user@shoutech.com", "User", "ROLE_USER", UsrAccLvl.User, false),
            ["viewer"] = new("USR-003", "مستخدم عرض", "viewer@shoutech.com", "Viewer", "ROLE_VIEWER", UsrAccLvl.Viewer, false),
        };

        private UserInfo? _currentUser;

        public bool IsAuthenticated => _currentUser?.IsAuthenticated == true;

        public async Task<AuthResult> LoginAsync(string username, string password)
        {
            var normalizedUser = username?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(normalizedUser) || string.IsNullOrEmpty(password))
            {
                return new AuthResult
                {
                    Success = false,
                    Message = "اسم المستخدم أو كلمة المرور غير صحيحة"
                };
            }

            var companyCode = AppState.CurrentCompanyCode ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(companyCode))
            {
                var localCompany = await CoLocalStore.FindUserCompanyAsync(companyCode, normalizedUser, password);
                if (localCompany != null)
                {
                    _currentUser = BuildCompanyAdminUser(normalizedUser, localCompany);
                    SyncSession(_currentUser);
                    return new AuthResult
                    {
                        Success = true,
                        Message = "تم تسجيل الدخول بنجاح",
                        User = _currentUser
                    };
                }

                var dbUser = await TryLoginFromDatabaseAsync(companyCode, normalizedUser, password);
                if (dbUser != null)
                {
                    _currentUser = dbUser;
                    SyncSession(_currentUser);
                    return new AuthResult
                    {
                        Success = true,
                        Message = "تم تسجيل الدخول بنجاح",
                        User = _currentUser
                    };
                }
            }

            if (!Profiles.TryGetValue(normalizedUser, out var profile) || password != normalizedUser)
            {
                return new AuthResult
                {
                    Success = false,
                    Message = "اسم المستخدم أو كلمة المرور غير صحيحة"
                };
            }

            _currentUser = BuildUserInfo(normalizedUser, profile);
            SyncSession(_currentUser);

            return new AuthResult
            {
                Success = true,
                Message = "تم تسجيل الدخول بنجاح",
                User = _currentUser
            };
        }

        public Task LogoutAsync()
        {
            _currentUser = null;
            UsrSession.Clear();
            AppState.CurrentUser = null;
            return Task.CompletedTask;
        }

        public Task<UserInfo?> GetCurrentUserAsync() => Task.FromResult(_currentUser);

        public void SetCurrentUser(UserInfo user)
        {
            _currentUser = user;
            SyncSession(user);
        }

        private static UserInfo BuildCompanyAdminUser(string username, StoredCoRec company)
        {
            return new UserInfo
            {
                Id = company.CompanyId.ToString(),
                Username = username,
                FullName = company.AdminFullName,
                Email = company.Email,
                Role = "Administrator",
                RoleCode = "ROLE_COMPANY_ADMIN",
                AccessLevel = UsrAccLvl.Administrator,
                IsSuperAdmin = true,
                CompanyId = company.Code,
                CompanyName = company.Name,
                IsAuthenticated = true,
                LastLogin = System.DateTime.Now
            };
        }

        private static async Task<UserInfo?> TryLoginFromDatabaseAsync(string companyCode, string username, string password)
        {
            try
            {
                var connectionString = AppCfgSvc.Current?.ConnectionStrings?
                    .FirstOrDefault(kvp => kvp.Key.Equals("Default", StringComparison.OrdinalIgnoreCase)).Value?.ConnectionString;

                if (string.IsNullOrWhiteSpace(connectionString))
                {
                    connectionString = AppCfgSvc.Current?.ConnectionStrings?.Values?.FirstOrDefault()?.ConnectionString;
                }

                if (string.IsNullOrWhiteSpace(connectionString))
                    return null;

                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT TOP 1
                        u.UserID, u.Username, u.PasswordHash, u.PasswordSalt,
                        u.FullNameAR, u.FullNameEN, u.Email,
                        c.CompanyCode, c.CompanyNameAR
                    FROM dbo.Users u
                    INNER JOIN dbo.Companies c ON c.CompanyID = u.CompanyID
                    WHERE c.CompanyCode = @CompanyCode
                      AND u.Username = @Username
                      AND u.IsActive = 1
                      AND u.IsDeleted = 0
                      AND c.IsActive = 1
                      AND c.IsDeleted = 0;";

                await using var command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@CompanyCode", companyCode);
                command.Parameters.AddWithValue("@Username", username);

                await using var reader = await command.ExecuteReaderAsync();
                if (!await reader.ReadAsync())
                    return null;

                var hash = reader["PasswordHash"]?.ToString() ?? string.Empty;
                var salt = reader["PasswordSalt"]?.ToString() ?? string.Empty;

                if (!PwdHash.Verify(password, hash, salt))
                    return null;

                return new UserInfo
                {
                    Id = reader["UserID"]?.ToString() ?? string.Empty,
                    Username = username,
                    FullName = reader["FullNameAR"]?.ToString() ?? username,
                    Email = reader["Email"]?.ToString() ?? string.Empty,
                    Role = "Administrator",
                    RoleCode = "ROLE_COMPANY_ADMIN",
                    AccessLevel = UsrAccLvl.Administrator,
                    IsSuperAdmin = true,
                    CompanyId = reader["CompanyCode"]?.ToString() ?? companyCode,
                    CompanyName = reader["CompanyNameAR"]?.ToString() ?? GetCompanyName(),
                    IsAuthenticated = true,
                    LastLogin = System.DateTime.Now
                };
            }
            catch
            {
                return null;
            }
        }

        private static UserInfo BuildUserInfo(string username, CredentialProfile profile)
        {
            return new UserInfo
            {
                Id = profile.Id,
                Username = username,
                FullName = profile.FullName,
                Email = profile.Email,
                Role = profile.Role,
                RoleCode = profile.RoleCode,
                AccessLevel = profile.AccessLevel,
                IsSuperAdmin = profile.IsSuperAdmin,
                CompanyId = AppState.CurrentCompanyCode ?? "MAIN",
                CompanyName = GetCompanyName(),
                IsAuthenticated = true,
                LastLogin = System.DateTime.Now
            };
        }

        private static void SyncSession(UserInfo user)
        {
            UsrSession.Apply(user);

            AppState.CurrentUser = new global::ShouTech.App.UserInfo
            {
                Username = user.Username,
                FullName = user.FullName,
                Role = user.Role,
                RoleCode = user.RoleCode,
                AccessLevel = user.AccessLevel,
                IsSuperAdmin = user.IsSuperAdmin,
                IsAuthenticated = user.IsAuthenticated
            };
        }

        private static string GetCompanyName()
        {
            if (System.Windows.Application.Current?.Properties["SelectedCompany"] is ShouTech.App.Views.CompanyItem company)
                return company.NameAr;

            return "الشركة الرئيسية";
        }
    }
}
