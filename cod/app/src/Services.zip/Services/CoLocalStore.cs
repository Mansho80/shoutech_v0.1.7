using System.Globalization;
using System.IO;
using System.Text.Json;
using ShouTech.App.Common;

namespace ShouTech.App.Services
{
    public static class CoLocalStore
    {
        private static readonly string StorePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ShouTech", "ERP", "data", "companies.json");

        public static async Task<List<StoredCoRec>> LoadAsync()
        {
            try
            {
                if (!File.Exists(StorePath))
                    return new List<StoredCoRec>();

                var json = await File.ReadAllTextAsync(StorePath);
                var file = JsonSerializer.Deserialize<StoredCoFile>(json, JsonDefs.AppSetngRead);
                return file?.Companies?.Where(c => c.Enabled).ToList() ?? new List<StoredCoRec>();
            }
            catch
            {
                return new List<StoredCoRec>();
            }
        }

        public static async Task SaveCompanyAsync(StoredCoRec company)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(StorePath)!);

            var file = new StoredCoFile();
            if (File.Exists(StorePath))
            {
                try
                {
                    var json = await File.ReadAllTextAsync(StorePath);
                    file = JsonSerializer.Deserialize<StoredCoFile>(json, JsonDefs.AppSetngRead) ?? new StoredCoFile();
                }
                catch
                {
                    file = new StoredCoFile();
                }
            }

            var existing = file.Companies.FirstOrDefault(c =>
                string.Equals(c.Code, company.Code, StringComparison.OrdinalIgnoreCase));

            if (existing != null)
                file.Companies.Remove(existing);

            file.Companies.Add(company);

            var temp = StorePath + ".tmp";
            var output = JsonSerializer.Serialize(file, JsonDefs.Indented);
            await File.WriteAllTextAsync(temp, output);
            File.Move(temp, StorePath, overwrite: true);
        }

        public static async Task<StoredCoRec?> FindUserCompanyAsync(string companyCode, string username, string password)
        {
            var companies = await LoadAsync();
            var company = companies.FirstOrDefault(c =>
                string.Equals(c.Code, companyCode, StringComparison.OrdinalIgnoreCase));

            if (company == null)
                return null;

            if (!string.Equals(company.AdminUsername, username, StringComparison.OrdinalIgnoreCase))
                return null;

            return PwdHash.Verify(password, company.AdminPasswordHash, company.AdminPasswordSalt)
                ? company
                : null;
        }

        public static async Task<string> GenerateNextCodeAsync()
        {
            var companies = await LoadAsync();
            var max = 0;

            foreach (var code in companies.Select(c => c.Code))
            {
                if (int.TryParse(code, out var n) && n > max)
                    max = n;
            }

            return (max + 1).ToString("000", CultureInfo.InvariantCulture);
        }
    }
}
