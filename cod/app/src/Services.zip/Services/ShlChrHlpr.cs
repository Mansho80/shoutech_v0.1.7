using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Controls.Ribbon;
using System.Windows.Media;

namespace ShouTech.App.Services
{
    /// <summary>
    /// Applies consistent shell chrome colors for menu, toolbar, and ribbon surfaces.
    /// </summary>
    public static class ShlChrHlpr
    {
        public static void Apply(Window? window)
        {
            if (window == null)
                return;

            if (window.FindName("RibbonControl") is Ribbon ribbon)
                ApplyRibbon(ribbon);

            if (IsLtTheme())
            {
                ApplyBlackText(window);
            }
        }

        public static void ApplyRibbon(Ribbon? ribbon)
        {
            if (ribbon == null)
                return;

            var background = GetBrush(ribbon, "ShellRibbonBackgroundBrush", "#F0F0F0");
            var foreground = GetBrush(ribbon, "ShellRibbonForegroundBrush", "#000000");
            var border = GetBrush(ribbon, "ShellRibbonBorderBrush", "#D0D0D0");
            var hover = GetBrush(ribbon, "ShellRibbonHoverBrush", "#E8E8E8");
            var forceBlackText = IsLtTheme();

            ribbon.Background = background;
            ribbon.Foreground = foreground;
            ribbon.BorderBrush = border;
            ribbon.MouseOverBackground = hover;
            ribbon.PressedBackground = hover;
            ribbon.CheckedBackground = background;
            ribbon.FocusedBackground = background;

            ApplyRibbonVisualTree(ribbon, background, foreground, forceBlackText);
        }

        private static void ApplyBlackText(DependencyObject root)
        {
            var foreground = GetBrush(root, "TextBrush", "#000000");

            if (root is Menu or ToolBar or MenuItem or StatusBar)
            {
                if (root is Control control)
                    control.Foreground = foreground;
            }

            if (root is TextBlock textBlock)
            {
                if (!IsInsideStatusBar(textBlock))
                {
                    textBlock.Foreground = foreground;
                    textBlock.FontFamily = new FontFamily("Tahoma");
                    textBlock.FontWeight = FontWeights.Bold;
                }
            }

            if (root is Button button && button.Parent is ToolBar)
                button.Foreground = foreground;

            var childCount = VisualTreeHelper.GetChildrenCount(root);
            for (var i = 0; i < childCount; i++)
                ApplyBlackText(VisualTreeHelper.GetChild(root, i));
        }

        private static void ApplyRibbonVisualTree(
            DependencyObject root,
            Brush background,
            Brush foreground,
            bool forceBlackText)
        {
            var childCount = VisualTreeHelper.GetChildrenCount(root);
            for (var i = 0; i < childCount; i++)
            {
                var child = VisualTreeHelper.GetChild(root, i);

                switch (child)
                {
                    case RibbonButton button:
                        button.Foreground = foreground;
                        break;

                    case Border border when ShouldRecolorChrome(border.Background):
                        border.Background = background;
                        break;

                    case Panel panel when ShouldRecolorChrome(panel.Background):
                        panel.Background = background;
                        break;

                    case TextBlock textBlock when forceBlackText || ShouldRecolorText(textBlock.Foreground):
                        textBlock.Foreground = foreground;
                        textBlock.FontFamily = new FontFamily("Tahoma");
                        textBlock.FontWeight = FontWeights.Bold;
                        break;

                    case RibbonGroup group:
                        group.Background = background;
                        group.Foreground = foreground;
                        break;

                    case RibbonTab tab:
                        tab.Background = background;
                        tab.Foreground = foreground;
                        break;
                }

                ApplyRibbonVisualTree(child, background, foreground, forceBlackText);
            }
        }

        private static bool IsInsideStatusBar(DependencyObject element)
        {
            while (element != null)
            {
                if (element is StatusBar)
                    return true;

                element = VisualTreeHelper.GetParent(element);
            }

            return false;
        }

        private static bool IsLtTheme()
        {
            return System.Windows.Application.Current?.TryFindResource("ThemeName") is string theme
                && theme.Equals("Light", StringComparison.OrdinalIgnoreCase);
        }

        private static bool ShouldRecolorChrome(Brush? brush)
        {
            if (brush == null)
                return true;

            return GetLuminance(brush) < 220;
        }

        private static bool ShouldRecolorText(Brush? brush)
        {
            if (brush == null)
                return true;

            return GetLuminance(brush) > 180;
        }

        private static double GetLuminance(Brush brush)
        {
            if (brush is not SolidColorBrush solid)
                return 128;

            var color = solid.Color;
            return 0.299 * color.R + 0.587 * color.G + 0.114 * color.B;
        }

        private static SolidColorBrush GetBrush(DependencyObject element, string key, string fallbackHex)
        {
            if (element is FrameworkElement fe && fe.TryFindResource(key) is SolidColorBrush brush)
                return brush;

            if (System.Windows.Application.Current?.TryFindResource(key) is SolidColorBrush appBrush)
                return appBrush;

            return new SolidColorBrush((Color)ColorConverter.ConvertFromString(fallbackHex)!);
        }
    }
}
