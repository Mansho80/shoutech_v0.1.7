// ========================================================================
// FILE: Services/UsrPrefSvc.cs (UserPreferencesService)
// ========================================================================
using System.Windows;
using ShouTech.App.Configuration;

namespace ShouTech.App.Services
{
    public interface IUsrPrefSvc
    {
        UsrPref Get();
        void Save(UsrPref prefs);
        void ApplyToWindow(Window window);
        void SaveFromWindow(Window window);
    }

    public class UsrPrefSvc : IUsrPrefSvc
    {
        private UsrPref _prefs;

        public UsrPrefSvc()
        {
            _prefs = UsrPref.Load();
        }

        public UsrPref Get() => _prefs;

        public void Save(UsrPref prefs)
        {
            _prefs = prefs;
            _prefs.Save();
        }

        public void ApplyToWindow(Window window) => _prefs.ApplyToWindow(window);

        public void SaveFromWindow(Window window) => _prefs.SaveFromWindow(window);
    }
}