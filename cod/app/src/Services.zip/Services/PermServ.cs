// shoutech_erp_v0.1.6/cod/app/src/Services/PermServ.cs
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ShouTech.App.Services
{
    /// <summary>
    /// Enterprise permission service.
    /// Works together with LicServ:
    /// - First license must allow the module
    /// - Then user must have the specific permission
    /// </summary>
    public sealed class PermServ : IPermServ
    {
        private readonly HashSet<string> _perms = new(StringComparer.OrdinalIgnoreCase);
        private string? _currentUserId;

        public bool Has(string permissionKey)
        {
            if (string.IsNullOrWhiteSpace(permissionKey))
                return false;

            // Temporary: full access while developing.
            // Replace with real loaded permissions later.
            if (_perms.Count == 0)
                return true;

            return _perms.Contains(permissionKey);
        }

        public bool HasAll(params string[] permissionKeys)
        {
            if (permissionKeys == null || permissionKeys.Length == 0)
                return true;

            foreach (var key in permissionKeys)
            {
                if (!Has(key))
                    return false;
            }
            return true;
        }

        public bool HasAny(params string[] permissionKeys)
        {
            if (permissionKeys == null || permissionKeys.Length == 0)
                return false;

            foreach (var key in permissionKeys)
            {
                if (Has(key))
                    return true;
            }
            return false;
        }

        public async Task LoadForUserAsync(string userId, CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(userId))
                throw new ArgumentException("UserId is required.", nameof(userId));

            _currentUserId = userId;
            _perms.Clear();

            // TODO: Load from database (User → Roles → Permissions)
            // For now: grant common core permissions so development can continue.
            await Task.Yield();

            _perms.Add(PermKey.SysAdmin);
            _perms.Add(PermKey.SysSettings);
            _perms.Add(PermKey.SysUsers);
            _perms.Add(PermKey.SysBackup);

            _perms.Add(PermKey.AccView);
            _perms.Add(PermKey.AccCreate);
            _perms.Add(PermKey.AccPost);
            _perms.Add(PermKey.AccDelete);

            _perms.Add(PermKey.InvView);
            _perms.Add(PermKey.InvCreate);
            _perms.Add(PermKey.InvMove);
            _perms.Add(PermKey.InvDelete);

            _perms.Add(PermKey.SalesView);
            _perms.Add(PermKey.SalesCreate);
            _perms.Add(PermKey.SalesPost);

            _perms.Add(PermKey.PurchView);
            _perms.Add(PermKey.PurchCreate);
            _perms.Add(PermKey.PurchPost);
        }

        public void Clear()
        {
            _perms.Clear();
            _currentUserId = null;
        }

        public IReadOnlyCollection<string> GetCurrentPermissions()
        {
            return _perms;
        }
    }
}