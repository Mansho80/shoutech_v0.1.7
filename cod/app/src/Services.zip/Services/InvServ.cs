// shoutech_erp_v0.1.6/cod/app/src/Services/InvServ.cs
using System;
using System.Threading;
using System.Threading.Tasks;

namespace ShouTech.App.Services
{
    /// <summary>
    /// Enterprise Inventory service.
    /// Protected by License (CanWrite + Module INV) and Permissions.
    /// </summary>
    public sealed class InvServ : IInvServ
    {
        private readonly ILicServ _lic;
        private readonly IPermServ _perm;
        // private readonly IInvRepo _repo; // سيُربط لاحقاً مع طبقة البيانات

        public InvServ(ILicServ lic, IPermServ perm)
        {
            _lic = lic ?? throw new ArgumentNullException(nameof(lic));
            _perm = perm ?? throw new ArgumentNullException(nameof(perm));
        }

        public async Task<Guid> CreateItemAsync(
            string code, string name, string? name2, Guid categoryId,
            string unit, decimal cost, decimal price, string userId,
            CancellationToken ct = default)
        {
            await _lic.EnsureCanWriteAsync(ct);
            await _lic.EnsureModuleAsync(ModKey.Inv, ct);

            if (!_perm.Has(PermKey.InvCreate))
                throw new UnauthorizedAccessException("You do not have permission to create items.");

            if (string.IsNullOrWhiteSpace(code))
                throw new ArgumentException("Item code is required.");
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Item name is required.");
            if (cost < 0 || price < 0)
                throw new ArgumentException("Cost and Price cannot be negative.");

            // TODO: استدعاء المستودع الحقيقي (Dapper / Repository)
            // حالياً نرجع Guid جديد كـ placeholder
            return Guid.NewGuid();
        }

        public async Task UpdateItemAsync(
            Guid id, string name, string? name2, Guid categoryId,
            string unit, decimal cost, decimal price, string userId,
            CancellationToken ct = default)
        {
            await _lic.EnsureCanWriteAsync(ct);
            await _lic.EnsureModuleAsync(ModKey.Inv, ct);

            if (!_perm.Has(PermKey.InvCreate))
                throw new UnauthorizedAccessException("You do not have permission to update items.");

            if (id == Guid.Empty)
                throw new ArgumentException("Invalid item id.");
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Item name is required.");
        }

        public async Task SoftDeleteItemAsync(Guid id, string userId, CancellationToken ct = default)
        {
            await _lic.EnsureCanWriteAsync(ct);
            await _lic.EnsureModuleAsync(ModKey.Inv, ct);

            if (!_perm.Has(PermKey.InvDelete))
                throw new UnauthorizedAccessException("You do not have permission to delete items.");

            if (id == Guid.Empty)
                throw new ArgumentException("Invalid item id.");
        }

        public async Task<bool> ItemCodeExistsAsync(string code, Guid? excludeId = null, CancellationToken ct = default)
        {
            await _lic.EnsureModuleAsync(ModKey.Inv, ct);
            // TODO: استعلام حقيقي
            return false;
        }

        public async Task<Guid> PostStockInAsync(
            Guid warehouseId, Guid itemId, decimal qty, decimal cost,
            string? refDoc, string userId, CancellationToken ct = default)
        {
            await _lic.EnsureCanWriteAsync(ct);
            await _lic.EnsureModuleAsync(ModKey.Inv, ct);

            if (!_perm.Has(PermKey.InvMove))
                throw new UnauthorizedAccessException("You do not have permission to post stock movements.");

            if (qty <= 0)
                throw new ArgumentException("Quantity must be greater than zero.");
            if (cost < 0)
                throw new ArgumentException("Cost cannot be negative.");

            return Guid.NewGuid();
        }

        public async Task<Guid> PostStockOutAsync(
            Guid warehouseId, Guid itemId, decimal qty,
            string? refDoc, string userId, CancellationToken ct = default)
        {
            await _lic.EnsureCanWriteAsync(ct);
            await _lic.EnsureModuleAsync(ModKey.Inv, ct);

            if (!_perm.Has(PermKey.InvMove))
                throw new UnauthorizedAccessException("You do not have permission to post stock movements.");

            if (qty <= 0)
                throw new ArgumentException("Quantity must be greater than zero.");

            var available = await GetAvailableQtyAsync(warehouseId, itemId, ct);
            if (available < qty)
                throw new InvalidOperationException("Insufficient stock quantity.");

            return Guid.NewGuid();
        }

        public async Task<decimal> GetAvailableQtyAsync(Guid warehouseId, Guid itemId, CancellationToken ct = default)
        {
            await _lic.EnsureModuleAsync(ModKey.Inv, ct);
            // TODO: استعلام حقيقي من قاعدة البيانات
            return 0m;
        }
    }
}