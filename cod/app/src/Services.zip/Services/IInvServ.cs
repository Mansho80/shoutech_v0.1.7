// shoutech_erp_v0.1.6/cod/app/src/Services/IInvServ.cs
using System;
using System.Threading;
using System.Threading.Tasks;

namespace ShouTech.App.Services
{
    public interface IInvServ
    {
        // Items
        Task<Guid> CreateItemAsync(string code, string name, string? name2, Guid categoryId,
            string unit, decimal cost, decimal price, string userId, CancellationToken ct = default);

        Task UpdateItemAsync(Guid id, string name, string? name2, Guid categoryId,
            string unit, decimal cost, decimal price, string userId, CancellationToken ct = default);

        Task SoftDeleteItemAsync(Guid id, string userId, CancellationToken ct = default);

        Task<bool> ItemCodeExistsAsync(string code, Guid? excludeId = null, CancellationToken ct = default);

        // Stock
        Task<Guid> PostStockInAsync(Guid warehouseId, Guid itemId, decimal qty, decimal cost,
            string? refDoc, string userId, CancellationToken ct = default);

        Task<Guid> PostStockOutAsync(Guid warehouseId, Guid itemId, decimal qty,
            string? refDoc, string userId, CancellationToken ct = default);

        Task<decimal> GetAvailableQtyAsync(Guid warehouseId, Guid itemId, CancellationToken ct = default);
    }
}