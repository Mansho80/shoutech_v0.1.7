using System;
using System.Threading.Tasks;

namespace ShouTech.App.Services.Online
{
    public enum LicenseStatus
    {
        Unknown,
        Valid,
        Expired,
        InvalidHardware,
        NotActivated,
        OfflineGrace
    }

    public sealed class LicenseInfo
    {
        public string LicenseKey { get; set; } = string.Empty;
        public string HardwareId { get; set; } = string.Empty;
        public DateTime ExpiryDate { get; set; } = DateTime.MaxValue;
        public DateTime? ActivatedAt { get; set; }
        public DateTime? LastOnlineCheck { get; set; }
        public LicenseStatus Status { get; set; } = LicenseStatus.Unknown;
        public bool IsOfflineMode { get; set; }
    }

    public interface ILicenSvc
    {
        LicenseInfo Current { get; }
        bool IsValid { get; }
        bool AllowsOfflineOperation { get; }

        LicenseStatus ValidateOffline();
        Task<LicenseStatus> TryOnlineValidationAsync();
        Task<LicenseStatus> InitializeAsync();
    }
}
