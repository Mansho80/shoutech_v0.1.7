// shoutech_erp_v0.1.6/cod/app/src/Services/BkpServ.cs
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace ShouTech.App.Services
{
    /// <summary>
    /// Enterprise backup service (placeholder for real encrypted backup engine).
    /// </summary>
    public sealed class BkpServ : IBkpServ
    {
        private readonly ILicServ _lic;
        private readonly IPermServ _perm;
        private readonly ILoggingService _log;

        public BkpServ(ILicServ lic, IPermServ perm, ILoggingService log)
        {
            _lic = lic;
            _perm = perm;
            _log = log;
        }

        public async Task<string> CreateBackupAsync(string companyCode, CancellationToken ct = default)
        {
            await _lic.EnsureCanWriteAsync(ct);

            if (!_perm.Has(PermKey.SysBackup))
                throw new UnauthorizedAccessException("You do not have permission to create backups.");

            if (string.IsNullOrWhiteSpace(companyCode))
                throw new ArgumentException("Company code is required.");

            var root = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "ShouTech", "ERP", "Backups", companyCode);

            Directory.CreateDirectory(root);

            var fileName = $"{companyCode}_FULL_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.bak";
            var fullPath = Path.Combine(root, fileName);

            // TODO: تنفيذ النسخ الحقيقي + التشفير AES-256
            await File.WriteAllTextAsync(fullPath, $"ShouTech Backup Placeholder - {DateTime.UtcNow:O}", ct);

            _log.LogInfo("Backup", $"Backup created: {fullPath}");
            return fullPath;
        }

        public async Task RestoreBackupAsync(string backupFilePath, CancellationToken ct = default)
        {
            await _lic.EnsureCanWriteAsync(ct);

            if (!_perm.Has(PermKey.SysBackup))
                throw new UnauthorizedAccessException("You do not have permission to restore backups.");

            if (!File.Exists(backupFilePath))
                throw new FileNotFoundException("Backup file not found.", backupFilePath);

            // TODO: فك التشفير + الاستعادة الحقيقية
            await Task.Yield();
            _log.LogInfo("Backup", $"Restore requested: {backupFilePath}");
        }

        public async Task<bool> ValidateBackupAsync(string backupFilePath, CancellationToken ct = default)
        {
            await Task.Yield();
            return File.Exists(backupFilePath);
        }
    }
}