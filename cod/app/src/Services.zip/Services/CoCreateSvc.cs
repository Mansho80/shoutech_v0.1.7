using System.Data;
using System.Globalization;
using System.IO;
using Microsoft.Data.SqlClient;
using ShouTech.App.Common;
using ShouTech.App.Configuration;

namespace ShouTech.App.Services
{
    public sealed class CoCreateSvc : ICoCreateSvc
    {
        public async Task<CoCreateResult> CreateAsync(NewCoReq request)
        {
            var companyId = Guid.NewGuid();
            var code = await ResolveCompanyCodeAsync();
            var (hash, salt) = PwdHash.Create(request.AdminPassword);
            var fullName = string.IsNullOrWhiteSpace(request.AdminFullName)
                ? request.AdminUsername
                : request.AdminFullName;

            var record = new StoredCoRec
            {
                CompanyId = companyId,
                Code = code,
                Name = request.CompanyNameAr.Trim(),
                NameEn = string.IsNullOrWhiteSpace(request.CompanyNameEn)
                    ? request.CompanyNameAr.Trim()
                    : request.CompanyNameEn.Trim(),
                Email = request.Email.Trim(),
                Phone = request.Phone.Trim(),
                Mobile = request.Mobile.Trim(),
                AddressLine1 = request.AddressLine1?.Trim() ?? string.Empty,
				AddressLine2 = request.AddressLine2?.Trim() ?? string.Empty,
				City = request.City?.Trim() ?? string.Empty,
				Country = request.Country?.Trim() ?? string.Empty,
                License = request.License.Trim(),
                Notes = request.Notes.Trim(),
                FiscalYearStart = request.FiscalYearStart.Date,
                FiscalYearEnd = request.FiscalYearEnd.Date,
                CurrencyCode = request.CurrencyCode,
                DecimalPlaces = request.DecimalPlaces,
                CalendarType = request.CalendarType,
                NumberGrouping = request.NumberGrouping,
                AdminUsername = request.AdminUsername.Trim(),
                AdminPasswordHash = hash,
                AdminPasswordSalt = salt,
                AdminFullName = fullName,
                DbPath = request.DbPath.Trim(),
                BackupPath = request.BackupPath.Trim(),
                AutoBackup = request.AutoBackup
            };

            var savedToDb = await TrySaveToDatabaseAsync(record, request);
            await CoLocalStore.SaveCompanyAsync(record);

            return new CoCreateResult
            {
                Success = true,
                CompanyCode = code,
                CompanyNameAr = record.Name,
                SavedToDatabase = savedToDb,
                SavedLocally = true,
                Message = savedToDb
                    ? "تم إنشاء الشركة وتسجيلها في قاعدة البيانات."
                    : "تم إنشاء الشركة وحفظها محلياً (قاعدة البيانات غير متاحة)."
            };
        }

        private static async Task<string> ResolveCompanyCodeAsync()
        {
            var localCode = await CoLocalStore.GenerateNextCodeAsync();
            var dbCode = await TryGenerateDbCodeAsync();

            if (string.IsNullOrWhiteSpace(dbCode))
                return localCode;

            if (int.TryParse(localCode, out var localNum) &&
                int.TryParse(dbCode, out var dbNum))
            {
                return Math.Max(localNum, dbNum).ToString("000", CultureInfo.InvariantCulture);
            }

            return dbCode;
        }

        private static async Task<string?> TryGenerateDbCodeAsync()
        {
            try
            {
                var connectionString = ResolveConnectionString();
                if (string.IsNullOrWhiteSpace(connectionString))
                    return null;

                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT MAX(TRY_CAST(CompanyCode AS int))
                    FROM dbo.Companies
                    WHERE IsDeleted = 0;";

                await using var command = new SqlCommand(sql, connection);
                var value = await command.ExecuteScalarAsync();
                var max = value is int i ? i : value is decimal d ? (int)d : 0;
                return (max + 1).ToString("000", CultureInfo.InvariantCulture);
            }
            catch
            {
                return null;
            }
        }

        private static async Task<bool> TrySaveToDatabaseAsync(StoredCoRec record, NewCoReq request)
        {
            try
            {
                var connectionString = ResolveConnectionString();
                if (string.IsNullOrWhiteSpace(connectionString))
                    return false;

                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();
                await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync();

                try
                {
                    const string insertCompany = @"
                        INSERT INTO dbo.Companies
                        (
                            CompanyID, CompanyCode, CompanyNameAR, CompanyNameEN,
                            Email, Phone, Mobile, AddressLine1, CommercialRegistration,
                            CurrencyCode, LanguageCode, IsActive, IsDeleted
                        )
                        VALUES
                        (
                            @CompanyId, @Code, @NameAr, @NameEn,
                            @Email, @Phone, @Mobile, @Address, @License,
                            @Currency, 'ar-SY', 1, 0
                        );";

                    await using (var cmd = new SqlCommand(insertCompany, connection, transaction))
                    {
                        cmd.Parameters.Add("@CompanyId", SqlDbType.UniqueIdentifier).Value = record.CompanyId;
                        cmd.Parameters.Add("@Code", SqlDbType.NVarChar, 50).Value = record.Code;
                        cmd.Parameters.Add("@NameAr", SqlDbType.NVarChar, 250).Value = record.Name;
                        cmd.Parameters.Add("@NameEn", SqlDbType.NVarChar, 250).Value = record.NameEn;
                        cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 255).Value = NullIfEmpty(record.Email);
                        cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 50).Value = NullIfEmpty(record.Phone);
                        cmd.Parameters.Add("@Mobile", SqlDbType.NVarChar, 50).Value = NullIfEmpty(record.Mobile);
                        cmd.Parameters.Add("@AddressLine1", SqlDbType.NVarChar, 255).Value = NullIfEmpty(record.AddressLine1);
						cmd.Parameters.Add("@AddressLine2", SqlDbType.NVarChar, 255).Value = NullIfEmpty(record.AddressLine2);
						cmd.Parameters.Add("@City", SqlDbType.NVarChar, 100).Value = NullIfEmpty(record.City);
						cmd.Parameters.Add("@Country", SqlDbType.NVarChar, 100).Value = NullIfEmpty(record.Country);
                        cmd.Parameters.Add("@License", SqlDbType.NVarChar, 100).Value = NullIfEmpty(record.License);
                        cmd.Parameters.Add("@Currency", SqlDbType.Char, 3).Value = record.CurrencyCode;
                        await cmd.ExecuteNonQueryAsync();
                    }

                    var fiscalYear = record.FiscalYearStart.Year;
                    var dbName = string.IsNullOrWhiteSpace(record.DbPath)
                        ? $"SHOUTECH_{record.Code}_{fiscalYear}"
                        : Path.GetFileName(record.DbPath.TrimEnd('\\', '/'));

                    const string insertFiscal = @"
                        INSERT INTO dbo.FiscalYears
                        (
                            CompanyID, FiscalYear, DatabaseName, StartDate, EndDate, IsCurrent, IsClosed
                        )
                        VALUES
                        (
                            @CompanyId, @FiscalYear, @DbName, @StartDate, @EndDate, 1, 0
                        );";

                    await using (var cmd = new SqlCommand(insertFiscal, connection, transaction))
                    {
                        cmd.Parameters.Add("@CompanyId", SqlDbType.UniqueIdentifier).Value = record.CompanyId;
                        cmd.Parameters.Add("@FiscalYear", SqlDbType.Int).Value = fiscalYear;
                        cmd.Parameters.Add("@DbName", SqlDbType.NVarChar, 128).Value = dbName;
                        cmd.Parameters.Add("@StartDate", SqlDbType.Date).Value = record.FiscalYearStart;
                        cmd.Parameters.Add("@EndDate", SqlDbType.Date).Value = record.FiscalYearEnd;
                        await cmd.ExecuteNonQueryAsync();
                    }

                    const string insertUser = @"
                        INSERT INTO dbo.Users
                        (
                            CompanyID, Username, PasswordHash, PasswordSalt,
                            FullNameAR, FullNameEN, Email, MustChangePassword, IsActive, IsDeleted
                        )
                        VALUES
                        (
                            @CompanyId, @Username, @Hash, @Salt,
                            @FullName, @FullName, @Email, 0, 1, 0
                        );";

                    await using (var cmd = new SqlCommand(insertUser, connection, transaction))
                    {
                        cmd.Parameters.Add("@CompanyId", SqlDbType.UniqueIdentifier).Value = record.CompanyId;
                        cmd.Parameters.Add("@Username", SqlDbType.NVarChar, 100).Value = record.AdminUsername;
                        cmd.Parameters.Add("@Hash", SqlDbType.NVarChar, 500).Value = record.AdminPasswordHash;
                        cmd.Parameters.Add("@Salt", SqlDbType.NVarChar, 500).Value = record.AdminPasswordSalt;
                        cmd.Parameters.Add("@FullName", SqlDbType.NVarChar, 250).Value = record.AdminFullName;
                        cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 255).Value = NullIfEmpty(record.Email);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    await transaction.CommitAsync();
                    return true;
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                AppHost.Logging.LogWarning("CoCreateSvc", $"Database save failed: {ex.Message}");
                return false;
            }
        }

        private static object NullIfEmpty(string value)
            => string.IsNullOrWhiteSpace(value) ? DBNull.Value : value.Trim();

        private static string? ResolveConnectionString()
        {
            var connectionString = AppCfgSvc.Current?.ConnectionStrings?
                .FirstOrDefault(kvp => kvp.Key.Equals("Default", StringComparison.OrdinalIgnoreCase)).Value?.ConnectionString;

            if (string.IsNullOrWhiteSpace(connectionString))
            {
                connectionString = AppCfgSvc.Current?.ConnectionStrings?.Values?.FirstOrDefault()?.ConnectionString;
            }

            return connectionString;
        }
    }
}
