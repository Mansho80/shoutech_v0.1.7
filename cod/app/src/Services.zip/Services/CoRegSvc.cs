using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using ShouTech.App.Configuration;

namespace ShouTech.App.Services
{
    public class CoRegSvc : ICoRegSvc
    {
        public async Task<List<CompanyInfo>> GetCompaniesAsync()
        {
            var merged = new Dictionary<string, CompanyInfo>(StringComparer.OrdinalIgnoreCase);

            foreach (var company in await LoadFromDatabaseAsync())
            {
                if (!string.IsNullOrWhiteSpace(company.Code))
                    merged[company.Code] = company;
            }

            foreach (var local in await CoLocalStore.LoadAsync())
            {
                if (string.IsNullOrWhiteSpace(local.Code) || merged.ContainsKey(local.Code))
                    continue;

                merged[local.Code] = new CompanyInfo
                {
                    Code = local.Code,
                    Name = local.Name,
                    NameEn = local.NameEn,
                    Database = string.IsNullOrWhiteSpace(local.DbPath) ? "LOCAL" : local.DbPath,
                    Enabled = local.Enabled,
                    IsDefault = false
                };
            }

            if (merged.Count > 0)
                return merged.Values.OrderBy(c => c.Code).ToList();

            return AppCfgSvc.Current?.MultiCompany?.Companies?
                .Where(c => c?.Enabled == true)
                .ToList() ?? new List<CompanyInfo>();
        }

        public async Task<bool> HasCompaniesAsync()
        {
            var companies = await GetCompaniesAsync();
            return companies.Any(c => c?.Enabled == true);
        }

        private static async Task<List<CompanyInfo>> LoadFromDatabaseAsync()
        {
            var result = new List<CompanyInfo>();

            try
            {
                var connectionString = AppCfgSvc.Current?.ConnectionStrings?
                    .FirstOrDefault(kvp => kvp.Key.Equals("Default", StringComparison.OrdinalIgnoreCase)).Value?.ConnectionString;

                if (string.IsNullOrWhiteSpace(connectionString))
                {
                    connectionString = AppCfgSvc.Current?.ConnectionStrings?.Values?.FirstOrDefault()?.ConnectionString;
                }

                if (string.IsNullOrWhiteSpace(connectionString))
                    return result;

                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT CompanyCode, CompanyNameAR, CompanyNameEN, CurrencyCode, LanguageCode, IsActive, IsDeleted
                    FROM dbo.Companies
                    WHERE IsDeleted = 0 AND IsActive = 1
                    ORDER BY CompanyNameAR;
                ";

                await using var command = new SqlCommand(sql, connection);
                await using var reader = await command.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    result.Add(new CompanyInfo
                    {
                        Code = reader["CompanyCode"]?.ToString() ?? string.Empty,
                        Name = reader["CompanyNameAR"]?.ToString() ?? string.Empty,
                        NameEn = reader["CompanyNameEN"]?.ToString() ?? string.Empty,
                        Database = connection.Database,
                        Enabled = true,
                        IsDefault = string.Equals(reader["CompanyCode"]?.ToString(), AppCfgSvc.Current?.MultiCompany?.DefaultCompanyCode, StringComparison.OrdinalIgnoreCase)
                    });
                }
            }
            catch
            {
                return result;
            }

            return result;
        }
    }
}
