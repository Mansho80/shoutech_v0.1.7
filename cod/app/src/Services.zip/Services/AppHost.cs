using ShouTech.App.Configuration;
using ShouTech.App.Services.Online;

namespace ShouTech.App.Services
{
    /// <summary>
    /// Composition root for application-wide services (lightweight service locator).
    /// </summary>
    public static class AppHost
    {
        private static bool _initialized;

        public static ILogServ Logging { get; private set; } = new LogServ();
        public static IThmServ Theme { get; private set; } = new ThmServ();
        public static INavServ Navigation { get; private set; } = null!;
        public static IAuthSvc Auth { get; private set; } = new AuthServ();
        public static IDataServ Data { get; private set; } = new DataServ();
        public static ICoCreateSvc CompanyCreation { get; private set; } = new CoCreateSvc();
        public static IPermServ Permissions { get; private set; } = new PermServ();
        public static IBkpServ Backup { get; private set; } = null!;
        public static IConnSvc Connectivity { get; private set; } = null!;
        public static IDevInfoSvoSv DeviceInfo { get; private set; } = null!;
        public static ILicenSvc License { get; private set; } = null!;
        public static ISyncServ Sync { get; private set; } = null!;
        public static IOnlCoord OnlineCoordinator { get; private set; } = null!;

        // ✅ الخدمات الجديدة
        public static ISessionManager Session { get; private set; } = new SessionManager();
        public static IAuditService Audit { get; private set; } = null!;

        public static ILocSvc Localization =>
            System.Windows.Application.Current is App app ? app.Localization : _fallbackLocalization;

        private static readonly LocSvc _fallbackLocalization = new();

        public static void Initialize()
        {
            if (_initialized)
                return;

            AppCfgSvc.Load();

            Logging = new LogServ();
            Theme = new ThmServ();
            Navigation = new NavServ(Logging);
            Auth = new AuthServ();
            Data = new DataServ();
            CompanyCreation = new CoCreateSvc();
            Permissions = new PermServ();

            Connectivity = new ConnServ(Logging);
            DeviceInfo = new DevInfoSv(Logging);
            License = new LicenSvc(Logging, DeviceInfo);
            Sync = new SyncServ(Logging, DeviceInfo);
            Backup = new BkpServ(Logging, DeviceInfo, Sync);
            OnlineCoordinator = new OnlCoord(
                Connectivity, License, Backup, Sync, DeviceInfo, Logging);

            // ✅ تهيئة خدمة التدقيق
            Audit = new AuditService(Logging);

            var usrPref = UsrPref.Load();
            var isDark = !string.Equals(usrPref.Theme, "Light", System.StringComparison.OrdinalIgnoreCase);
            Theme.Initialize(isDark);

            _initialized = true;
            Logging.LogInfo("AppHost", "Services initialized (offline-first)");

            // ✅ تسجيل بداية تشغيل النظام
            _ = Audit.LogSystemStartAsync();
        }
    }
}